/* 
 * File:   PWM.h
 * Author: TP-EO-1
 *
 * Created on 7 septembre 2020, 10:24
 */

#ifndef PWM_H
#define	PWM_H

void InitPWM(void);
//void PWMSetSpeed(float,unsigned char);
void PWMUpdateSpeed();
void PWMSetSpeedConsigne(float, char);
#endif	/* PWM_H */