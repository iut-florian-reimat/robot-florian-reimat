#ifndef UART_H



// Functions
void InitUART(void);
void SendMessageDirect(unsigned char*,int);
#endif /* UART_H */
