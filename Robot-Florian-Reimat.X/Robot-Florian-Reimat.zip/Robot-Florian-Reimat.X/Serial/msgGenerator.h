/* 
 * File:   msgGenerator.h
 * Author: Florian REIMAT
 *
 * Created on 10 novembre 2020, 10:19
 */

#ifndef MSGGENERATOR_H
#define	MSGGENERATOR_H

void GenerateStateMessage(unsigned char);
void GenerateTextMessage(unsigned char*);

#endif	/* MSGGENERATOR_H */

