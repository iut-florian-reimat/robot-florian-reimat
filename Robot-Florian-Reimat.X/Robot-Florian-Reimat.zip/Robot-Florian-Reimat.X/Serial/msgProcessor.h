/* 
 * File:   msgProcessor.h
 * Author: TABLE 6
 *
 * Created on 10 novembre 2020, 10:06
 */

#ifndef MSGPROCESSOR_H
#define	MSGPROCESSOR_H

void UartProcessDecodedMessage(int , unsigned char* );
#endif	/* MSGPROCESSOR_H */

