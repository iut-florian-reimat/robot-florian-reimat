/* 
 * File:   QEI..h
 * Author: TABLE 6
 *
 * Created on 1 octobre 2020, 18:31
 */

#ifndef QEI__H
#define	QEI__H

void InitQEI1();
void InitQEI2();

#endif	/* QEI__H */

